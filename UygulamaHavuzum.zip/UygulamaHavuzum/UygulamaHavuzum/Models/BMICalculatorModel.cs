﻿namespace UygulamaHavuzum.Models
{
    public class BMICalculatorModel
    {
        public float Weight { get; set; }
        public float Height { get; set; }
        public string? YourBMI { get; set; }
        public float BMIResult { get; set; }
    }
}
